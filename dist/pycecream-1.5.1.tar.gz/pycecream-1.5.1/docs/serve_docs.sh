#!/bin/bash

python docs/autogen.py
pydocmd serve
