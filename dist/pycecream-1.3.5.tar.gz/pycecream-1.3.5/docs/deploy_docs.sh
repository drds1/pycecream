#!/bin/bash

python docs/autogen.py
pydocmd gh-deploy
