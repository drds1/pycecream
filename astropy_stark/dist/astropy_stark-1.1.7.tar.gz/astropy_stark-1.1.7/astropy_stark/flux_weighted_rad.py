#code to return a flux weighted radius for a given temp radius law

import numpy as np
from myplank import *


